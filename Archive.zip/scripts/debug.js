if (!window.VK_UP) {
    VK_UP = 38;
}
if (!window.VK_DOWN) {
    VK_DOWN = 40;
}
if (!window.VK_LEFT) {
    VK_LEFT = 37;
}
if (!window.VK_RIGHT) {
    VK_RIGHT = 39;
}
if (!window.VK_ENTER) {
    VK_ENTER = 13;
}
if (!window.VK_BACK) {
    VK_BACK = 461; // ESC
}
if (!window.VK_PLAY) {
    VK_PLAY = 415; // 'P'
}
if (!window.VK_PAUSE) {
    VK_PAUSE = 19; // 'Z'
}
if (!window.VK_STOP) {
    VK_STOP = 413; // 'S'
}
if (!window.VK_FAST_FWD) {
    VK_FAST_FWD = 417;
}
if (!window.VK_REWIND) {
    VK_REWIND = 412;
}
if (!window.VK_PAGE_UP) {
    VK_PAGE_UP = 33;
}
if (!window.VK_PAGE_DOWN) {
    VK_PAGE_DOWN = 34;
}
if (!window.VK_RED) {
    VK_RED = 403;
}
if (!window.VK_BLUE) {
    VK_BLUE = 406;
}
if (!window.VK_GREEN) {
    VK_GREEN = 404;
}
if (!window.VK_YELLOW) {
    VK_YELLOW = 405; // 8
}