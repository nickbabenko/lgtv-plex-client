1. create developer account by lg (free)
2. login with this account on your TV
3. create zip with all files and upload it by lg
4. download signed package
5. unzip the package to usb stick to "lgapps/installed/XXXXXX"  <- XXXXX is folder with app-id exmaple 1234567
6. put stick in your tv and enjoy
